# SocialBoost - Social Media Boosting Platform

A complete social media boosting service platform built with React, TypeScript, and Tailwind CSS.

## Features

- ✅ Multi-platform support (TikTok, Instagram, Facebook, WhatsApp, Telegram)
- ✅ User authentication & authorization
- ✅ Wallet-based payment system with screenshot verification
- ✅ Referral program with earnings (₦100 per referral)
- ✅ Comprehensive admin panel
- ✅ Dynamic pricing system
- ✅ Order tracking & history
- ✅ Real-time balance updates

## Installation

```bash
npm install
npm run dev
```

## Admin Access

Email: hollysanju@gmail.com  
Password: karldarko

## Tech Stack

- React 18.3.1
- TypeScript 5.5.3
- Tailwind CSS 3.4.11
- React Router DOM 6.x
- Lucide React (Icons)
- Sonner (Toast Notifications)
- shadcn/ui Components

## Project Structure

```
src/
├── components/
│   ├── ui/            # shadcn/ui components
│   └── layout/        # Layout components
├── pages/             # Page components
│   └── admin/         # Admin panel pages
├── lib/               # Utilities & helpers
├── types/             # TypeScript definitions
├── constants/         # App constants & config
└── assets/            # Static assets
```

## How It Works

### For Users
1. Sign up with email and optional referral code
2. Top up wallet via bank transfer
3. Upload payment screenshot for verification
4. Wait for admin approval
5. Once approved, order boosts for any platform
6. Track orders in real-time

### For Admin
1. Login with admin credentials
2. Review and approve/reject payment requests
3. Manage user accounts (ban/delete)
4. Configure pricing for all services
5. Update bank details and API settings
6. Monitor platform statistics

## License

MIT