import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import { getCurrentUser } from '@/lib/auth';
import Header from '@/components/layout/Header';
import Login from '@/pages/Login';
import Signup from '@/pages/Signup';
import Dashboard from '@/pages/Dashboard';
import OrderPage from '@/pages/OrderPage';
import TopUp from '@/pages/TopUp';
import Orders from '@/pages/Orders';
import Referral from '@/pages/Referral';
import Profile from '@/pages/Profile';
import AdminDashboard from '@/pages/admin/AdminDashboard';

function App() {
  const user = getCurrentUser();

  return (
    <BrowserRouter>
      <Toaster position="top-center" richColors />
      {user && <Header />}
      <Routes>
        <Route path="/login" element={!user ? <Login /> : <Navigate to={user.isAdmin ? '/admin' : '/dashboard'} />} />
        <Route path="/signup" element={!user ? <Signup /> : <Navigate to="/dashboard" />} />
        <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/login" />} />
        <Route path="/order/:platform" element={user ? <OrderPage /> : <Navigate to="/login" />} />
        <Route path="/topup" element={user ? <TopUp /> : <Navigate to="/login" />} />
        <Route path="/orders" element={user ? <Orders /> : <Navigate to="/login" />} />
        <Route path="/referral" element={user ? <Referral /> : <Navigate to="/login" />} />
        <Route path="/profile" element={user ? <Profile /> : <Navigate to="/login" />} />
        <Route path="/admin" element={user?.isAdmin ? <AdminDashboard /> : <Navigate to="/login" />} />
        <Route path="/" element={<Navigate to={user ? (user.isAdmin ? '/admin' : '/dashboard') : '/login'} />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;